# CodeAlpha - Car Price Prediction

## Project Overview

This project predicts used car selling prices using machine learning techniques.

The project analyzes factors such as present price, car age, driven kilometers, fuel type, transmission, selling type, ownership, and car name popularity to understand their relationship with selling price.

## Objectives

- Analyze the used car dataset.
- Clean and prepare the data.
- Perform exploratory data analysis.
- Create useful features such as car age and name popularity.
- Encode categorical variables.
- Train machine learning regression models.
- Compare Linear Regression and Random Forest models.
- Evaluate models using R2, MAE, and RMSE.
- Identify important features affecting car selling price.
- Generate visualizations for better understanding.

## Dataset

The dataset contains information about used cars.

### Main Columns

- `Car_Name` - Name of the car
- `Year` - Manufacturing year
- `Selling_Price` - Selling price of the car
- `Present_Price` - Current/ex-showroom price
- `Driven_kms` - Kilometers driven
- `Fuel_Type` - Fuel type of the car
- `Selling_type` - Dealer or Individual
- `Transmission` - Manual or Automatic
- `Owner` - Number of previous owners

## Technologies Used

- Python
- Jupyter Notebook
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn

## Project Steps

### 1. Data Loading and Exploration

The car dataset was loaded using Pandas and its structure, data types, and missing values were examined.

### 2. Data Cleaning

Duplicate records were removed and missing values were checked.

### 3. Feature Engineering

Two additional features were created:

- `Car_Age`
- `Name_Popularity`

### 4. Encoding

Categorical variables such as fuel type, selling type, and transmission were converted into numerical features using one-hot encoding.

### 5. Train/Test Split

The dataset was divided into training and testing sets using an 80/20 split.

### 6. Machine Learning Models

Two regression models were trained:

- Linear Regression
- Random Forest Regressor

### 7. Model Evaluation

Models were evaluated using:

- R2 Score
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)

Five-fold cross-validation was also performed.

### 8. Visualization

The project includes visualizations for:

- Selling price distribution
- Correlation matrix
- Present price vs selling price
- Selling price by fuel type
- Actual vs predicted prices
- Random Forest feature importance

## Results

### Single 80/20 Train-Test Split

| Model | R2 | MAE | RMSE |
|---|---:|---:|---:|
| Linear Regression | 0.744 | 1.487 | 2.567 |
| Random Forest | 0.436 | 1.476 | 3.812 |

### Five-Fold Cross-Validation

- Linear Regression mean R2: **0.848**
- Random Forest mean R2: **0.847**

The cross-validation results show that both models perform similarly on average, with Linear Regression performing slightly better.

## Important Features

The Random Forest model identified the following important features:

- Present Price
- Car Age
- Name Popularity
- Driven Kms
- Transmission

The most important feature was `Present_Price`.

## Sample Prediction

For one test example:

- Actual selling price: **8.99 Lakhs**
- Predicted selling price: **9.70 Lakhs**

## Project Structure

```text
CodeAlpha_Car_Price_Prediction/
│
├── Car_Price_Prediction.ipynb
├── car data.csv
├── README.md
├── requirements.txt
│
└── outputs/
    ├── 01_price_distribution.png
    ├── 02_correlation_matrix.png
    ├── 03_present_vs_selling.png
    ├── 04_price_by_fueltype.png
    ├── 05_actual_vs_predicted.png
    └── 06_feature_importance.png