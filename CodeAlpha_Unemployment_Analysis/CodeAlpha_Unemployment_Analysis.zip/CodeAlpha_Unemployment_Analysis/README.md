# Unemployment Analysis in India

## CodeAlpha Data Science Internship Project

### Project Overview

This project analyzes unemployment trends in India using unemployment data from 2019 to 2020.

The analysis focuses on understanding unemployment patterns across different regions and areas, studying the impact of COVID-19 and the lockdown period, identifying seasonal trends, and examining the relationship between unemployment, employment, and labour participation.

The project was developed using Python in a Jupyter Notebook.

## Objectives

- Analyze unemployment trends over time.
- Compare unemployment rates between rural and urban areas.
- Identify states with higher average unemployment rates.
- Analyze the impact of COVID-19 and the lockdown on unemployment.
- Study seasonal unemployment patterns.
- Create visualizations to understand unemployment trends.
- Analyze correlations between unemployment, employment, and labour participation.
- Generate useful insights from the data.

## Dataset

The dataset contains unemployment-related information for different regions of India.

### Dataset Columns

- Region
- Date
- Frequency
- Estimated Unemployment Rate (%)
- Estimated Employed
- Estimated Labour Participation Rate (%)
- Area

## Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Jupyter Notebook

## Project Workflow

### 1. Data Loading and Cleaning

The dataset was loaded using Pandas.

The following preprocessing steps were performed:

- Removed unnecessary whitespace from text columns.
- Converted the Date column into datetime format.
- Renamed columns for easier analysis.
- Removed duplicate records.
- Checked for missing values.
- Created Year, Month, and Month Name columns.

After cleaning, the dataset contained 740 records and 10 columns.

### 2. Exploratory Data Analysis

The project analyzes:

- Monthly unemployment trends.
- Rural vs Urban unemployment trends.
- Top 10 states by average unemployment rate.

### 3. COVID-19 Impact Analysis

The data was divided into two periods:

- Pre-COVID: Before 25 March 2020
- COVID/Post-Lockdown: From 25 March 2020 onwards

The average unemployment rate was:

- Pre-COVID: 9.51%
- COVID/Post-Lockdown: 17.77%

The highest unemployment rate observed in the dataset was 76.74% in April 2020 in Puducherry.

### 4. Seasonal Trend Analysis

Pre-COVID data was used to study monthly unemployment patterns without allowing the COVID-19 lockdown spike to dominate the seasonal analysis.

A state-versus-month heatmap was also created.

### 5. Correlation Analysis

A correlation matrix was created to examine relationships between:

- Unemployment Rate
- Estimated Employed
- Labour Participation Rate

## 6.Visualizations

The project contains the following visualizations:

1. Average Monthly Unemployment Rate
2. Rural vs Urban Unemployment Trend
3. Top 10 States by Average Unemployment Rate
4. Pre-COVID vs COVID Unemployment Distribution
5. State-wise Increase in Unemployment During COVID
6. Seasonal Unemployment Trend
7. State vs Month Unemployment Heatmap
8. Correlation Matrix

All visualizations are stored in the `outputs` folder.

The project includes:

1. National unemployment trend
2. Rural vs Urban comparison
3. Top 10 states by average unemployment
4. COVID-19 impact boxplot
5. State-wise COVID unemployment increase
6. Seasonal unemployment trend
7. State vs Month heatmap
8. Correlation matrix

## Key Insights

- The average unemployment rate increased substantially during the COVID-19 and lockdown period.
- The average unemployment rate increased from 9.51% before the COVID cutoff to 17.77% during the COVID/Post-Lockdown period.
- The highest unemployment rate recorded was 76.74% in April 2020 in Puducherry.
- Unemployment patterns varied across different regions.
- Rural and urban areas showed different unemployment trends.
- The analysis demonstrates how Python-based data analysis and visualization can be used to extract insights from real-world data.

## How to Run the Project

1. Install Python.
2. Install the required libraries:

```bash
pip install pandas numpy matplotlib seaborn jupyter
